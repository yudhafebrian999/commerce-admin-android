# Commerce Admin Android

Aplikasi Android WebView untuk membuka Commerce Admin.

URL:
https://commerce.flivo.id/admin

## Fitur
- Membuka Commerce Admin otomatis
- JavaScript & DOM Storage
- Cookie/login session
- Upload file/gambar dari website
- Pull-to-refresh
- Tombol Back mengikuti riwayat halaman WebView
- HTTPS only
- Portrait

## Build APK
Buka project ini di Android Studio, tunggu Gradle Sync selesai, lalu:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Package:
id.flivo.commerceadmin
